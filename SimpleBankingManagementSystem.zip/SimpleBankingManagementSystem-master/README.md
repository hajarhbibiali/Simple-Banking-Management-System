# SimpleBankingManagementSystem
This project is a simple Android application for managing banking operations, including credit, debit, and transfers between accounts.
![image](https://github.com/douaeelmz/SimpleBankingManagementSystem/assets/93287412/d3915c68-392d-4d70-b222-b72e0d5e61c2)
![image](https://github.com/douaeelmz/SimpleBankingManagementSystem/assets/93287412/24d42285-dbb5-462c-9b1d-5c0f238c687b)
